const chat=document.getElementById('chat'), form=document.getElementById('form'), input=document.getElementById('input');
function add(text,who){const row=document.createElement('div');row.className='msg '+who;const b=document.createElement('div');b.className='bubble';b.textContent=text;row.appendChild(b);chat.appendChild(row);chat.scrollTop=chat.scrollHeight}
function demoReply(t){return `Thanks for your message! This is AIRA's prototype.\n\nYou asked: “${t}”\n\nThe chat interface is working. The next step is connecting an AI API so AIRA can generate real answers.`}
form.addEventListener('submit',e=>{e.preventDefault();const t=input.value.trim();if(!t)return;document.querySelector('.welcome')?.remove();add(t,'user');input.value='';setTimeout(()=>add(demoReply(t),'ai'),450)});
document.querySelectorAll('.chips button').forEach(b=>b.onclick=()=>{input.value=b.textContent;input.focus()});
document.getElementById('newChat').onclick=()=>location.reload();